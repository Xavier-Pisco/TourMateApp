Instruções de compilação
	Corresponde a um projeto de CLion, desenvolvido em linux. Para compilar, importar o projeto no IDE.
	
Dependências
	Na pasta lib:
		RapidXML
		GraphViewer
